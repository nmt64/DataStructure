#define LAB2_TEST1	1		// Date constructors
#define LAB2_TEST2	1		// Date getters
#define LAB2_TEST3	1		// isLeapYear
#define LAB2_TEST4	1		// daysInMonth
#define LAB2_TEST5	1		// Date operator<<
#define LAB2_TEST6	1		// BlogEntry constructors
#define LAB2_TEST7	1		// BlogEntry getters/setters
#define LAB2_TEST8	0		// Exercise 1 - printHTML
#define LAB2_TEST9	0		// Exercise 2 - getDayOfWeek
#define LAB2_TEST10	0		// Exercise 3 - Date relational operators
