/**
 * Stack class (Lab 6) configuration file.
 * Activate test #N by defining the corresponding LAB6_TESTN to have the value 1.
 */

#define LAB6_TEST1	0	// 0 => use array implementation, 1 => use linked impl.

