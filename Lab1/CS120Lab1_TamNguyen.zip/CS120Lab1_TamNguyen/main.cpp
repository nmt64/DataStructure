//
//  main.cpp
//  Lab1
//
//  Created by Nguyen Tam on 1/17/18.
//  Copyright © 2018 Nguyen Tam. All rights reserved.
//

#include <iostream>   //include the input/output classes

using namespace std;  //use the standard C++ namespace so names do not have to be fully qualified
int main()
{
    //cout << "Hello World!\n";  //print Hello World! to the terminal followed by a return
    int a;
    int b;
    int c;
    cin >> a;
    cin >> b;
    cin >> c;
    cout << "The values you entered are " << a << " " << b << " " << c << ".\n";
    cout << "The sum of the three variable values is " << a + b + c << ".\n";
    cout << "The average of the three variable values is " << (a + b + c)/3 << ".\n";
    
    int max = a;
    int min = a;
    if (max < b)
        max = b;
    if (max < c)
        max = c;
    if (min > b)
        min = b;
    if (min > c)
        min = c;
    cout << "The largest value is " << max << ".\n" ;
    cout << "The smallest value is " << min << ".\n" ;
    return 0;            //successful termination of main
}

