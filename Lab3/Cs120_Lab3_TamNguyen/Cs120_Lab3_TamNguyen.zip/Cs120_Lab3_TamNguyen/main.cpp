//
//  main.cpp
//  CS120_LAB3_TamNguyen
//
//  Created by Nguyen Tam on 1/30/18.
//  Copyright © 2018 Nguyen Tam. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
